

class PyE57Exception(BaseException):
    pass